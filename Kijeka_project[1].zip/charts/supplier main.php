<?php
    session_start();
    if($_SESSION['is_login']){
        //keep the user on the page
    }else{
        //redirect on the login page
        header("Location: LOGIN.php");
    }
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- ===== BOX ICONS ===== -->
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>

        <!-- ===== CSS ===== -->
        <link rel="stylesheet" href="assets/css/style.css">
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <title>Sidebar menu responsive</title>
    </head>
    <body id="body-pd">
        <header class="header" id="header">
            <div class="header__toggle">
                <i class='bx bx-menu' id="header-toggle"></i>
            </div>

            <div >
            <h2>Kijeka Engineers PVT LTD</h2>            </div>
        </header>

        <div class="l-navbar" id="nav-bar">
            <nav class="nav">
            <div>
                    <a href="#" class="nav__logo">
                        <i class='bx bx-layer nav__logo-icon'></i>
                        <span class="nav__logo-name">Kijeka Engineers</span>
                    </a>

                    <div class="nav__list">
                        <a href="Dashboard.php" class="nav__link ">
                        <i class='bx bx-grid-alt nav__icon' style='font-size:24px' ></i>
                            <span class="nav__name">Dashboard</span>
                        </a>

                        <a href="users 1.php" class="nav__link">
                            <i class='fas fa-user-alt' style='font-size:24px' ></i>
                            <span class="nav__name">Users</span>
                        </a>
                        <a href="customer main.php" class="nav__link">
                            <i class='fab fa-cc-visa' style='font-size:24px' ></i>
                            <span class="nav__name">Customer</span>
                        </a>
                        <a href="product main.php" class="nav__link">
                            <i class='fas fa-cart-plus' style='font-size:24px' ></i>
                            <span class="nav__name">Product</span>
                        </a>

                        <a href="warehouse main.php" class="nav__link">
                            <i class='fas fa-house-user' style='font-size:24px' ></i>
                            <span class="nav__name">Warehouse</span>
                        </a>

                        <a href="supplier main.php" class="nav__link active">
                            <i class='fas fa-shuttle-van' style='font-size:24px' ></i>
                            <span class="nav__name">Supplier</span>
                        </a>

                    </div>
                </div>

                <a href="logout.php" class="nav__link">
                    <i class='bx bx-log-out nav__icon' ></i>
                    <span class="nav__name">Log Out</span>
                </a>
            </nav>
        </div>
        <div>

        <section id="chapters">
            <h1 class="heading"><b>SUPPLIER</b></h1>
            <div class="row">
                <a href="supplier 3.php"> <div class="box">
                    <h2 class="heading">Supplier Entry</h2>
                </div></a>
                <a href="supplier 2.php"> <div class="box">
                    <h2 class="heading">SUPPLIER VIEW FROM SUPPLIER NAME</h2>
                </div></a>
               <a href="supplier 1.php"> <div class="box">
                    <h2 class="heading">SUPPLIER VIEW FROM SUPPLIER NAME AND SUPPLIER CODE</h2>
                </div> </a>
            </div>
        </section>
                <style>
                
#chapters h1
{
    color: darkgreen;
    border-radius: 8in ;
    text-align: center;
    font-size: 3rem;
    font-weight: bolder;
    font-family: 'Courier New', Courier, monospace;
}
#chapters h2
{
    font-size: 2rem;
    text-align: center;
    justify-content: center;
    padding: 20px;
    font-weight: bolder;
    font-style: italic;
    font-family: 'Courier New', Courier, monospace;
}
.type
{
    font-size: larger;
    text-align: center;
    padding: 2px;
    font-family: 'Courier New', Courier, monospace;
    text-align: justify;
    margin-left: 10%;
    font-weight: bold;
}
.row
{
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    box-sizing: border-box;
}
.box
{
    display: flex;
    flex-direction: column;
    width: 400px;
    height: 350px;
    border: 2px solid aqua;
    margin: 10px;
    align-items: center;
    text-align: center;
    padding: 10px;
    border-radius: 15px;
    background: linear-gradient(to top, rgb(184, 0, 212) 50%,rgb(255, 255, 255) 50%);
    background-size: 100% 200%;
    transition: all 0.8s;
    box-shadow: 0 0 50px rgb(38, 80, 106);
}
.box:hover
{
    background-position: left bottom;
    color: white;
    border: none;
    box-shadow: 0 0 50px rgba(0, 17, 255, 0.849);
}
                </style>
                                            <!--===== MAIN JS =====-->
        <script src="assets/js/main.js"></script>
    </body>
</html>