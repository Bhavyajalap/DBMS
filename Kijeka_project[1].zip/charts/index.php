<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Kijeka Engineer pvt ltd</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#"/></div>
      </div>
      <!-- end loader -->
      <div id="mySidepanel" class="sidepanel">
         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
         <a class="active" href="index.html">Home</a>
         <a href="#about">About</a>
         <a href="#product">Products</a>
         <a href="contact us.php">Contact</a>
         <a href="login.php">Login</a>
      </div>
      <!-- header -->
      <header class="full_bg">
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row d_flex">
                  <div class=" col-md-2 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                              <a href="index.html"><img src="images/logo.gif" alt="#" /></a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-10 col-sm-9">
                     <ul class="site_menu text_align_right">
                        <li >
                           <button class="openbtn" onclick="openNav()"><img src="images/menu_icon.png"></button>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <!-- end header inner -->
         <!-- end header -->
         <section class="banner_main">
            <div id="myCarousel" class="carousel slide banner" data-ride="carousel">
               <ol class="carousel-indicators">
                  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                  <li data-target="#myCarousel" data-slide-to="1"></li>
                  <li data-target="#myCarousel" data-slide-to="2"></li>
               </ol>
               <div class="carousel-inner">
                  <div class="carousel-item active">
                     <div class="container">
                        <div class="carousel-caption  banner_po">
                           <div class="row">
                              <div class="col-md-8">
                                 <div class="build_box text_align_left">
                                    <h1>WELCOME<br> <span class="white">KIJEKA ENGINEERS</span></h1>
                                    <p>The mechanics of industry is easy. The real engine is the people :
                                       “Their motivation and direction.”</p>
                                    <a class="read_more conatct_btn" href="contact us.php" role="button">Contact now</a>
                                    <a class="read_more conatct_btn" href="#about" role="button">About Factory</a>
                                 </div>
                              </div>
                           </div>
                           <strong>best</strong>
                        </div>
                     </div>
                  </div>
                  <div class="carousel-item">
                     <div class="container">
                        <div class="carousel-caption banner_po">
                           <div class="row">
                              <div class="col-md-8">
                                 <div class="build_box text_align_left">
                                    <h1>WELCOME<br> <span class="white">KIJEKA ENGINEERS</span></h1>
                                    <p>Listen better. Plan better. Build better.</p>
                                    <a class="read_more conatct_btn" href="contact us.php" role="button">Contact now</a>
                                    <a class="read_more conatct_btn" href="#about" role="button">About Factory</a>
                                 </div>
                              </div>
                           </div>
                           <strong>best</strong>
                        </div>
                     </div>
                  </div>
                  <div class="carousel-item">
                     <div class="container">
                        <div class="carousel-caption banner_po">
                           <div class="row">
                              <div class="col-md-8">
                                 <div class="build_box text_align_left">
                                    <h1>WELCOME<br> <span class="white">KIJEKA ENGINEERS</span></h1>
                                    <p>Masters of consistency and quality.</p>
                                    <a class="read_more conatct_btn" href="contact us.php" role="button">Contact now</a>
                                    <a class="read_more conatct_btn" href="#about" role="button">About Factory</a>
                                 </div>
                              </div>
                           </div>
                           <strong>best</strong>
                        </div>
                     </div>
                  </div>
               </div>
               <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
               <i class="fa fa-angle-left" aria-hidden="true"></i>
               <span class="sr-only">Previous</span>
               </a>
               <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
               <i class="fa fa-angle-right" aria-hidden="true"></i>
               <span class="sr-only">Next</span>
               </a>
            </div>
         </section>
      </header>
      <!-- end banner -->
      <!-- about -->
      <div id="about" class="about">
         <div class="bg_about">
            <div class="container">
               <div class="row d_flex">
                  <div class="col-md-5">
                     <div class="about_img">
                        <figure><img src="images/about.jpg" alt="#"/></figure>
                     </div>
                  </div>
                  <div class="col-md-6 offset-md-1">
                     <div class="titlepage text_align_right">
                        <h2>About of Factory</h2>
                        <p>KIJEKA ENGINEERS</b> founded on 12th May 1980, by an Engineer <b>Mr. Rameshchandra Dave</b> having presence in Ahmedabad, Gujarat to provide Handling Solutions for the various Industries.

                           Since then <b>KIJEKA ENGINEERS</b> has excelled in providing practical and efficient methods of rotation, transfer, re-location and movement of materials and products weighing between 100 kgs and to well over 10,000 kgs. <b>KIJEKA ENGINEERS</b> professional team of experienced personnel supplies a wide range of standard or custom designed systems to meet assembly, tooling and material handling needs for large, awkward and heavy loads.
                           
                           <b>KIJEKA ENGINEERS</b> success is based upon our continuing research, development and integration of the latest technologies in moving and assembling heavy and cumbersome loads. Over the years <b>KIJEKA ENGINEERS</b> has become a problem-solving company that provides customers with solutions to their handling problems.
                        </p>
                        
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end about -->
      <!-- products -->
      <div id="product" class="prot">
         <div class="products">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <div class="titlepage text_align_left">
                        <h2>Our Some Products</h2>
                     </div>
                  </div>
               </div>
            </div>
            <div id="prod" class="carousel slide product_banner" data-ride="carousel">
               <ol class="carousel-indicators">
                  <li data-target="#prod" data-slide-to="0" class="active"></li>
                  <li data-target="#prod" data-slide-to="1"></li>
                  <li data-target="#prod" data-slide-to="2"></li>
               </ol>
               <div class="carousel-inner">
                  <div class="carousel-item active">
                     <div class="container">
                        <div class="carousel-caption  banner_pro">
                           <div class="row d_flex">
                              <div class="col-md-4">
                                 <div class="product mar_bottom30">
                                    <figure><img src="images/kijeka 1.jfif" alt="#"/></figure>
                                    <h3>Arial Works Platform</h3>
                                 </div>
                              </div>
                              <div class="col-md-4 mar_bottom30">
                                 <div class="product">
                                    <figure><img src="images/kijeka 2.jfif" alt="#"/></figure>
                                    <h3>Cranes and Lifting Accessories</h3>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="product">
                                    <figure><img src="images/kijeka 3.jfif" alt="#"/></figure>
                                    <h3>Chemical Pumps</h3>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="carousel-item">
                     <div class="container">
                        <div class="carousel-caption  banner_pro">
                           <div class="row d_flex">
                              <div class="col-md-4 mar_bottom30">
                                 <div class="product">
                                    <figure><img src="images/kijeka 4.jfif" alt="#"/></figure>
                                    <h3>Pallet Trucks</h3>
                                 </div>
                              </div>
                              <div class="col-md-4 mar_bottom30">
                                 <div class="product">
                                    <figure><img src="images/kijeka 5.jfif" alt="#"/></figure>
                                    <h3>Drum Handling Equipment</h3>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="product">
                                    <figure><img src="images/kijeka 6.jfif" alt="#"/></figure>
                                    <h3>Hand Trucks</h3>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="carousel-item">
                     <div class="container">
                        <div class="carousel-caption  banner_pro">
                           <div class="row d_flex">
                              <div class="col-md-4 mar_bottom30">
                                 <div class="product">
                                    <figure><img src="images/kijeka 7.jfif" alt="#"/></figure>
                                    <h3>Drum Trolley</h3>
                                 </div>
                              </div>
                              <div class="col-md-4 mar_bottom30">
                                 <div class="product">
                                    <figure><img src="images/kijeka 8.jfif" alt="#"/></figure>
                                    <h3>Drum Dollies</h3>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="product">
                                    <figure><img src="images/kijeka 9.jfif" alt="#"/></figure>
                                    <h3>Wire Reel Cart</h3>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <a class="carousel-control-prev" href="#prod" role="button" data-slide="prev">
               <i class="fa fa-arrow-left" aria-hidden="true"></i>
               <span class="sr-only">Previous</span>
               </a>
               <a class="carousel-control-next" href="#prod" role="button" data-slide="next">
               <i class="fa fa-arrow-right" aria-hidden="true"></i>
               <span class="sr-only">Next</span>
               </a>
            </div>
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <a class="read_more" href="https://www.kijeka.com/products/">See More</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end products -->
      <!--  contact -->
      <!-- end contact -->
      <!--  footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class=" col-md-10 offset-md-1">
                     <ul class="conta">
                        <li><i class="fa fa-map-marker" aria-hidden="true"></i>404, 4th floor, "ANUSHRI", Near Bank of Baroda, Ashram Road, Usmanpura, AHMEDABAD - 380 013, Gujarat State, India.
                        </li>
                        <li><i class="fa fa-volume-control-phone" aria-hidden="true"></i> +91-9879545352</li>
                        <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#"> info@kijeka.com</a></li>
                     </ul>
                  </div>
                  <div class="col-md-12">
                     <ul class="social_icon">
                        <li><a href="https://www.facebook.com/kijekaengg/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="https://twitter.com/kijeka"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <!-- <li><a href="Javascript:void(0)"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
                        <li><a href="Javascript:void(0)"><i class="fa fa-instagram" aria-hidden="true"></i></a></li> -->
                     </ul>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-10 offset-md-1">
                        <p>Copyright 2023  All Right Reserved By <a href="#">Harshil Khokhar</a></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>