<?php
  $con = mysqli_connect("localhost","root","","stock_management");
?>
<?php
    session_start();
    if($_SESSION['is_login']){
        //keep the user on the page
    }else{
        //redirect on the login page
        header("Location: LOGIN.php");
    }
?>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="assets/css/style1.css">
        <!-- ===== BOX ICONS ===== -->
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>

        <!-- ===== CSS ===== -->
        <link rel="stylesheet" href="assets/css/style.css">
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <title>Sidebar menu responsive</title>
        
    </head>
    <body id="body-pd">
        <header class="header" id="header">
            <div class="header__toggle">
                <i class='bx bx-menu' id="header-toggle"></i>
            </div>

            <div >
                <h2>Kijeka Engineers PVT LTD</h2>
            </div>
        </header>

        <div class="l-navbar" id="nav-bar">
            <nav class="nav">
                <div>
                    <a href="#" class="nav__logo">
                        <i class='bx bx-layer nav__logo-icon'></i>
                        <span class="nav__logo-name">Kijeka Engineers</span>
                    </a>

                    <div class="nav__list">
                        <a href="Dashboard.php" class="nav__link active">
                        <i class='bx bx-grid-alt nav__icon' style='font-size:24px' ></i>
                            <span class="nav__name">Dashboard</span>
                        </a>

                        <a href="users 1.php" class="nav__link">
                            <i class='fas fa-user-alt' style='font-size:24px' ></i>
                            <span class="nav__name">Users</span>
                        </a>
                        <a href="customer main.php" class="nav__link">
                            <i class='fab fa-cc-visa' style='font-size:24px' ></i>
                            <span class="nav__name">Customer</span>
                        </a>
                        <a href="product main.php" class="nav__link">
                            <i class='fas fa-cart-plus' style='font-size:24px' ></i>
                            <span class="nav__name">Product</span>
                        </a>

                        <a href="warehouse main.php" class="nav__link">
                            <i class='fas fa-house-user' style='font-size:24px' ></i>
                            <span class="nav__name">Warehouse</span>
                        </a>

                        <a href="supplier main.php" class="nav__link">
                            <i class='fas fa-shuttle-van' style='font-size:24px' ></i>
                            <span class="nav__name">Supplier</span>
                        </a>

                        
                    </div>
                </div>

                <a href="logout.php" class="nav__link">
                    <i class='bx bx-log-out nav__icon' style='font-size:24px' ></i>
                    <span class="nav__name">Log Out</span>
                </a>
            </nav>
        </div>
        <div class="cardBox">
        <div class="card">
            <div>
                <div class="numbers"><?php
                $sql = "SELECT sum(present_qty) AS qty
                FROM warehouse
                WHERE warehouse_code=1";
                $result = mysqli_query($con,$sql);
                $row = mysqli_fetch_assoc($result); 
                $sum = $row['qty'];
                echo $sum;
                ?></div>
                <div class="cardName">Warehouse 1 Products</div>
            </div>

            <div class="iconBx">
                <ion-icon name="eye-outline"></ion-icon>
            </div>
        </div>

        <div class="card">
        <div>
                <div class="numbers"><?php
                $sql = "SELECT sum(present_qty) AS qty
                FROM warehouse
                WHERE warehouse_code=2";
                $result = mysqli_query($con,$sql);
                $row = mysqli_fetch_assoc($result); 
                $sum = $row['qty'];
                echo $sum;
                ?></div>
                <div class="cardName">Warehouse 2 Products</div>
            </div>

            <div class="iconBx">
                <ion-icon name="eye-outline"></ion-icon>
            </div>
        </div>

        <div class="card">
        <div>
                <div class="numbers"><?php
                $sql = "SELECT sum(present_qty) AS qty
                FROM warehouse
                WHERE warehouse_code=3";
                $result = mysqli_query($con,$sql);
                $row = mysqli_fetch_assoc($result); 
                $sum = $row['qty'];
                echo $sum;
                ?></div>
                <div class="cardName">Warehouse 3 Products</div>
            </div>

            <div class="iconBx">
                <ion-icon name="eye-outline"></ion-icon>
            </div>
        </div>
        <div class="card">
        <div>
                <div class="numbers"><?php
                $sql = "SELECT count(order_code) AS code
                FROM customer" ;
                $result = mysqli_query($con,$sql);
                $row = mysqli_fetch_assoc($result); 
                $sum = $row['code'];
                echo $sum;
                ?></div>
                <div class="cardName">Total Orders</div>
            </div>

            <div class="iconBx">
                <ion-icon name="eye-outline"></ion-icon>
            </div>
        </div>

       
    </div>
    <div class="details">
                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Recent Orders</h2>
                    </div>

                    <!-- <table>
                        <thead>
                            <tr>
                                <td>Name</td>
                                <td>Price</td>
                                <td>Payment</td>
                                <td>Status</td>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>Star Refrigerator</td>
                                <td>$1200</td>
                                <td>Paid</td>
                                <td><span class="status delivered">Delivered</span></td>
                            </tr>

                            <tr>
                                <td>Dell Laptop</td>
                                <td>$110</td>
                                <td>Due</td>
                                <td><span class="status pending">Pending</span></td>
                            </tr>

                            <tr>
                                <td>Apple Watch</td>
                                <td>$1200</td>
                                <td>Paid</td>
                                <td><span class="status return">Return</span></td>
                            </tr>

                            <tr>
                                <td>Addidas Shoes</td>
                                <td>$620</td>
                                <td>Due</td>
                                <td><span class="status inProgress">In Progress</span></td>
                            </tr>

                            <tr>
                                <td>Star Refrigerator</td>
                                <td>$1200</td>
                                <td>Paid</td>
                                <td><span class="status delivered">Delivered</span></td>
                            </tr>

                            <tr>
                                <td>Dell Laptop</td>
                                <td>$110</td>
                                <td>Due</td>
                                <td><span class="status pending">Pending</span></td>
                            </tr>

                            <tr>
                                <td>Apple Watch</td>
                                <td>$1200</td>
                                <td>Paid</td>
                                <td><span class="status return">Return</span></td>
                            </tr>

                            <tr>
                                <td>Addidas Shoes</td>
                                <td>$620</td>
                                <td>Due</td>
                                <td><span class="status inProgress">In Progress</span></td>
                            </tr>
                        </tbody>
                    </table> --><?php
                    $sql = "SELECT customer_name,product_code,quantity,cost,status,date FROM customer ORDER BY order_code DESC LIMIT 8";
                    $result = $con->query($sql);
                    echo "<table><thead>
                <tr>
                <th>Customer Name</th>
                <th>product Code</th>
                <th>quantity</th>
                <th>cost</th>
                <th>Status</th>
                <th>Date</th></tr></thead>";
                while($row = $result->fetch_assoc()) {
                    echo "<tbody><tr>
                    <td>".$row["customer_name"]."</td>
                    <td>".$row["product_code"]."</td>
                    <td>".$row["quantity"]."</td>
                    <td>".$row["cost"]."</td>
                    <td>".$row["status"]."</td>
                    <td>".$row["date"]."</td></tr></tbody>";
                }
                echo "</table>";
            ?>    
            </div>

        <!--===== MAIN JS =====-->
        <script src="assets/js/main.js"></script>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    </body>
</html>