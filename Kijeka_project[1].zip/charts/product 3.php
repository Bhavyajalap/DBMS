<?php
    session_start();
    if($_SESSION['is_login']){
        //keep the user on the page
    }else{
        //redirect on the login page
        header("Location: LOGIN.php");
    }
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- ===== BOX ICONS ===== -->
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>

        <!-- ===== CSS ===== -->
        <link rel="stylesheet" href="assets/css/style.css">
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <title>Sidebar menu responsive</title>
    </head>
    <body id="body-pd">
        <header class="header" id="header">
            <div class="header__toggle">
                <i class='bx bx-menu' id="header-toggle"></i>
            </div>

            <div >
            <h2>Kijeka Engineers PVT LTD</h2>            </div>
        </header>

        <div class="l-navbar" id="nav-bar">
            <nav class="nav">
            <div>
                    <a href="#" class="nav__logo">
                        <i class='bx bx-layer nav__logo-icon'></i>
                        <span class="nav__logo-name">Kijeka Engineers</span>
                    </a>

                    <div class="nav__list">
                        <a href="Dashboard.php" class="nav__link active">
                        <i class='bx bx-grid-alt nav__icon' style='font-size:24px' ></i>
                            <span class="nav__name">Dashboard</span>
                        </a>

                        <a href="users 1.php" class="nav__link">
                            <i class='fas fa-user-alt' style='font-size:24px' ></i>
                            <span class="nav__name">Users</span>
                        </a>
                        <a href="customer main.php" class="nav__link">
                            <i class='fab fa-cc-visa' style='font-size:24px' ></i>
                            <span class="nav__name">Customer</span>
                        </a>
                        <a href="product main.php" class="nav__link active">
                            <i class='fas fa-cart-plus' style='font-size:24px' ></i>
                            <span class="nav__name">Product</span>
                        </a>

                        <a href="warehouse main.php" class="nav__link">
                            <i class='fas fa-house-user' style='font-size:24px' ></i>
                            <span class="nav__name">Warehouse</span>
                        </a>

                        <a href="supplier main.php" class="nav__link">
                            <i class='fas fa-shuttle-van' style='font-size:24px' ></i>
                            <span class="nav__name">Supplier</span>
                        </a>

                      
                    </div>
                </div>

                <a href="logout.php" class="nav__link">
                    <i class='bx bx-log-out nav__icon' ></i>
                    <span class="nav__name">Log Out</span>
                </a>
            </nav>
        </div>
        

        <h1>Product Entry</h1>
        <form
                                        action=" "
                                        method="post" id="contact" class="ucf" autocomplete="off">
                                        <fieldset>
                                            <!-- Form Name -->
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="product_code">
                                                            Product code</label>
                                                        <input id="pcode" name="pcode" type="number" placeholder="Product Code"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="product_code">
                                                            Product Name</label>
                                                        <input id="pname" name="pname" type="text" placeholder="Product Name"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="product_code">
                                                            Quantity</label>
                                                        <input id="qty" name="qty" type="Quantity" placeholder="Quantity"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="product_code">
                                                            warehouse code</label>
                                                        <input id="wcode" name="wcode" type="wcode" placeholder="Name"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <input type="submit" value="Submit" name="submit">
                                            </fieldset>
                                            </form>
                                            <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $conn = new mysqli($servername, $username, $password);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "CREATE DATABASE if not exists stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        $sql = "Use stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        if (isset($_REQUEST ['submit'])) {
            $pcode1 = $_POST['pcode'];
            $pname1 = $_POST['pname'];
            $qty = $_POST['qty'];
            $wcode1 = $_POST['wcode'];
            $sql = "SELECT * from product where product_code='$pcode1' or product_name='$pname1'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                echo "the user code or product name is already is in use";
            }
            else{ 
            $sql = "INSERT INTO product values($pcode1,'$pname1',$qty)";
            $result = $conn->query($sql);
            echo "details entered successfully";
            $sql = "INSERT INTO warehouse values($wcode1,$pcode1,$qty)";
            $result = $conn->query($sql);
            if ($wcode1 == 1)
            {
                $sql = "INSERT INTO warehouse values(2,$pcode1,0)";
            $result = $conn->query($sql);
            $sql = "INSERT INTO warehouse values(3,$pcode1,0)";
            $result = $conn->query($sql);
            }
            if ($wcode1 ==2)
            {
                $sql = "INSERT INTO warehouse values(1,$pcode1,0)";
            $result = $conn->query($sql);
            $sql = "INSERT INTO warehouse values(3,$pcode1,0)";
            $result = $conn->query($sql);
            }
            if ($wcode1 == 3)
            {
                $sql = "INSERT INTO warehouse values(2,$pcode1,0)";
            $result = $conn->query($sql);
            $sql = "INSERT INTO warehouse values(1,$pcode1,0)";
            $result = $conn->query($sql);
            }
            }
        }
        mysqli_close($conn);    
    ?>
                                            <!--===== MAIN JS =====-->
        <script src="assets/js/main.js"></script>
    </body>
</html>