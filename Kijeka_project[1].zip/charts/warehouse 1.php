<?php
    session_start();
    if($_SESSION['is_login']){
        //keep the user on the page
    }else{
        //redirect on the login page
        header("Location: LOGIN.php");
    }
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- ===== BOX ICONS ===== -->
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>

        <!-- ===== CSS ===== -->
        <link rel="stylesheet" href="assets/css/style.css">
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

        <title>Sidebar menu responsive</title>
        <style>
            table
            {
            border-collapse: collapse;
            width: 100%;
            color: orange;
            font-family: monospace;
            font-size: 25px;
            text-align: left;
            }
            th{
                background-color: blue;
                color: white;
            }
            tr: nth-child(even){
                background-color: #f2f2f2;  
            }
        </style>        
    </head>
    <body id="body-pd">
        <header class="header" id="header">
            <div class="header__toggle">
                <i class='bx bx-menu' id="header-toggle"></i>
            </div>

            <div >
            <h2>Kijeka Engineers PVT LTD</h2>            </div>
        </header>

        <div class="l-navbar" id="nav-bar">
            <nav class="nav">
            <div>
                    <a href="#" class="nav__logo">
                        <i class='bx bx-layer nav__logo-icon'></i>
                        <span class="nav__logo-name">Kijeka Engineers</span>
                    </a>

                    <div class="nav__list">
                        <a href="Dashboard.php" class="nav__link ">
                        <i class='bx bx-grid-alt nav__icon' style='font-size:24px' ></i>
                            <span class="nav__name">Dashboard</span>
                        </a>

                        <a href="users 1.php" class="nav__link">
                            <i class='fas fa-user-alt' style='font-size:24px' ></i>
                            <span class="nav__name">Users</span>
                        </a>
                        <a href="customer main.php" class="nav__link">
                            <i class='fab fa-cc-visa' style='font-size:24px' ></i>
                            <span class="nav__name">Customer</span>
                        </a>
                        <a href="product main.php" class="nav__link">
                            <i class='fas fa-cart-plus' style='font-size:24px' ></i>
                            <span class="nav__name">Product</span>
                        </a>

                        <a href="warehouse main.php" class="nav__link active">
                            <i class='fas fa-house-user' style='font-size:24px' ></i>
                            <span class="nav__name">Warehouse</span>
                        </a>

                        <a href="supplier main.php" class="nav__link">
                            <i class='fas fa-shuttle-van' style='font-size:24px' ></i>
                            <span class="nav__name">Supplier</span>
                        </a>

                        
                    </div>
                </div>

                <a href="logout.php" class="nav__link">
                    <i class='bx bx-log-out nav__icon' ></i>
                    <span class="nav__name">Log Out</span>
                </a>
            </nav>
        </div>

        <h1>Warehouse View</h1>
        <form
                                        action=""
                                        method="post" id="contact" class="ucf" autocomplete="off">
                                        <fieldset>
                                            <!-- Form Name -->
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="EMAIL">Product Code</label>
                                                        <input id="product_code" name="product_code" type="number" placeholder="Product code"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <input type="submit" value="Submit" name="submit">
                                            </fieldset>
                                            </form>
                                            <?php
        if (empty($_POST["product_code"])) {
            $warehouseerr = "code is required";
        } 
        $servername = "localhost";
        $username = "root";
        $password = "";
        $conn = new mysqli($servername, $username, $password);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "CREATE DATABASE if not exists stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        $sql = "Use stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        if (isset($_REQUEST ['submit'])) {
            $pcode1 = $_POST['product_code'];
            $sql = "SELECT * from warehouse where product_code='$pcode1'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                echo "<table>
                <tr>
                <th>warehouse code </th>
                <th>product code</th>
                <th>Quantity</th>
                </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>".$row["warehouse_code"]."</td><td>".$row["product_code"]."</td><td>".$row["present_qty"]."</td></tr>";
                }
                echo "</table>";
            }
            else
            {
                echo "You entered wrong Warehouse code.";
            }
        }
        mysqli_close($conn);
    ?>
                                            <!--===== MAIN JS =====-->
        <script src="assets/js/main.js"></script>
    </body>
</html>