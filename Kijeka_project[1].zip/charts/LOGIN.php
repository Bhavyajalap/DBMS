<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login page</title>
	<link rel="stylesheet" href="LOGIN.css">
</head>
<body>
	<div class="box">
		<form autocomplete="off" method="post">
			<h2>Sign in</h2>
			<div class="inputBox">
				<input name="email" type="text" required="required">
				<span>Email</span>
				<i></i>
			</div>
			<div class="inputBox">
				<input name="password2" type="password" required="required">
				<span>Password</span>
				<i></i>
			</div>
			<input type="submit" value="Login" name="submit">
		</form>
	</div>
	<?php
        if (empty($_POST["email"])) {
            $emailErr = "Email is required";
        } 
        else {
            $email = test_input($_POST["email"]);
            // check if e-mail address is well-formed
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
              $emailErr = "Invalid email format";
            }
        }
        if (empty($_POST["password2"])) {
            $passwordErr = "password is required";
          } else {
            $password2 = test_input($_POST["password2"]);
          }
        
        function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        $servername = "localhost";
        $username = "root";
        $password = "";
        $conn = new mysqli($servername, $username, $password);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "CREATE DATABASE if not exists stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        $sql = "Use stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        session_start();
        if(!isset($_SESSION['is_login'])){
        if (isset($_REQUEST ['submit'])) {
            $email = $_POST['email'];
            $password1 = $_POST['password2']; 
            $sql = "SELECT * FROM users WHERE email_id='$email' AND password='$password1'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                $sql = "INSERT INTO login VALUES ('$email','$password1',now())";
                
                $_SESSION['is_login'] = true;
                header("Location: Dashboard.php");
                
            }
            else {
                echo "You have entered wrong username or password";
            }
        }
        mysqli_close($conn);    
    }else{
        header("location: sidebar navigation.php");
    }
    ?>
</body>
</html>