<?php
    session_start();
    if($_SESSION['is_login']){
        //keep the user on the page
    }else{
        //redirect on the login page
        header("Location: LOGIN.php");
    }
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- ===== BOX ICONS ===== -->
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>

        <!-- ===== CSS ===== -->
        <link rel="stylesheet" href="assets/css/style.css">
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

        <title>Sidebar menu responsive</title>
    </head>
    <body id="body-pd">
        <header class="header" id="header">
            <div class="header__toggle">
                <i class='bx bx-menu' id="header-toggle"></i>
            </div>

            <div >
            <h2>Kijeka Engineers PVT LTD</h2>            </div>
        </header>

        <div class="l-navbar" id="nav-bar">
            <nav class="nav">
            <div>
                    <a href="#" class="nav__logo">
                        <i class='bx bx-layer nav__logo-icon'></i>
                        <span class="nav__logo-name">Kijeka Engineers</span>
                    </a>

                    <div class="nav__list">
                        <a href="Dashboard.php" class="nav__link ">
                        <i class='bx bx-grid-alt nav__icon' style='font-size:24px' ></i>
                            <span class="nav__name">Dashboard</span>
                        </a>

                        <a href="users 1.php" class="nav__link ">
                            <i class='fas fa-user-alt' style='font-size:24px' ></i>
                            <span class="nav__name">Users</span>
                        </a>
                        <a href="customer main.php" class="nav__link">
                            <i class='fab fa-cc-visa' style='font-size:24px' ></i>
                            <span class="nav__name">Customer</span>
                        </a>
                        <a href="product main.php" class="nav__link">
                            <i class='fas fa-cart-plus' style='font-size:24px' ></i>
                            <span class="nav__name">Product</span>
                        </a>

                        <a href="warehouse main.php" class="nav__link">
                            <i class='fas fa-house-user' style='font-size:24px' ></i>
                            <span class="nav__name">Warehouse</span>
                        </a>

                        <a href="supplier main.php" class="nav__link active">
                            <i class='fas fa-shuttle-van' style='font-size:24px' ></i>
                            <span class="nav__name">Supplier</span>
                        </a>

                       
                    </div>
                </div>

                <a href="logout.php" class="nav__link">
                    <i class='bx bx-log-out nav__icon' ></i>
                    <span class="nav__name">Log Out</span>
                </a>
            </nav>
        </div>
        <h1 style="text-align: center">Supplier entry</h1>
        <form
                                        action=""
                                        method="post" id="contact" class="ucf" autocomplete="off">
                                        <fieldset>
                                            <!-- Form Name -->
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="User Code">Warehouse Code</label>
                                                        <input id="ucode" name="ucode" type="number" placeholder="User Code"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="User Name">Supplier Name</label>
                                                        <input id="uname" name="uname" type="text" placeholder="Supplier Name"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="EMAIL">Mobile Number</label>
                                                        <input id="mobile_no" name="mobile_no" type="number" placeholder="Mobile Number"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="controls col-lg-12">
                                                    <p class="field-wrapper">
                                                        <label class="control-label" for="Vehicle Delivery">Vehicle Delivery</label>
                                                        <input id="password" name="password" type="text" placeholder="XXXXXXXXXX" onkeyup="
                                                                    var start = this.selectionStart;
                                                                    var end = this.selectionEnd;
                                                                    this.value = this.value.toUpperCase();
                                                                    this.setSelectionRange(start, end);
                                                                    " maxlenght="40"
                                                            class="input-xlarge form-control" style="width:100%;"
                                                            required>
                                                    </p>
                                                </div>
                                            </div>
                                            <input type="submit" value="Submit" name="submit">
                                            </fieldset>
                                            
                                            </form>
                                            <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $conn = new mysqli($servername, $username, $password);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "CREATE DATABASE if not exists stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        $sql = "Use stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        if (isset($_REQUEST ['submit'])) {
            $ucode1 = $_POST['ucode'];
            $uname1 = $_POST['uname'];
            $mobile_no1 = $_POST['mobile_no'];
            $passwd = $_POST['password'];
            $sql = "SELECT * from users where user_code='$ucode1'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0){
                echo "the user code is already is in use";
            }
            else{ 
            $sql = "INSERT INTO supplier values('$uname1',$ucode1,$mobile_no1,'$passwd',now())";
            $result = $conn->query($sql);
            echo "<h2>Details entered successfully<h2>";
            }
        }
        mysqli_close($conn);    
    ?>
                                            <!--===== MAIN JS =====-->
        <script src="assets/js/main.js"></script>
    </body>
</html>