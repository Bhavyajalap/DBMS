<?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $conn = new mysqli($servername, $username, $password);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "Use stock_management";
        if ($conn->query($sql) === FALSE) {
            echo "Error creating database: " . $conn->error;
        }
        if (isset($_REQUEST ['submit'])) {
            $product_code = $_POST['product_code1'];
            $sql = "SELECT * FROM product WHERE product_code='$product_code'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                echo "<table>
                <tr>
                <th>Product code</th>
                <th>product name</th>
                <th>Quantity</th></tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>".$row["product_code"]."</td>
                    <td>".$row["product_name"]."</td>
                    <td>".$row["QTY"]."</td></tr>";
                }
                echo "</table>";
            }
            else
            {
                echo "You entered wrong product_code.";
            }
        }
        mysqli_close($conn);
    ?>